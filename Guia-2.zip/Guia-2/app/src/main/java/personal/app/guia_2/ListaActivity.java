package personal.app.guia_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import personal.app.guia_2.model.Persona;

import static personal.app.guia_2.MainActivity.personas;

public class ListaActivity extends AppCompatActivity {

    ListView ListNombres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        ListNombres = findViewById(R.id.listNombres);

        ArrayAdapter<Persona> adapterPersona = new ArrayAdapter(this, android.R.layout.simple_list_item_1, personas);

        ListNombres.setAdapter(adapterPersona);

        adapterPersona.notifyDataSetChanged();

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}